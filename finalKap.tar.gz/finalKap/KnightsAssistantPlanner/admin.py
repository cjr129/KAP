from django.contrib import admin
from KnightsAssistantPlanner.models import events, workouts
# Register your models here.
admin.site.register(events)
admin.site.register(workouts)
